function hitungDiskon() {
      let hargaAwal = document.getElementById("harga").value;
      let diskon = document.getElementById("diskon").value;

      if (hargaAwal === "" || diskon === "") {
        document.getElementById("hasil").textContent = "wajib mengisi semua kolom!";
        return;
      }

      let potongan = (hargaAwal * diskon) / 100;
      let hargaAkhir = hargaAwal - potongan;

      let hasilRupiah = hargaAkhir.toLocaleString("id-ID");

      document.getElementById("hasil").textContent =
        "Harga setelah diskon adalah: Rp" + hasilRupiah;
    }