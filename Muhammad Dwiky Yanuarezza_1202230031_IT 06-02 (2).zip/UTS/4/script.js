$(document).ready(function() {
      $("#tambah").click(function() {
        var teks = $("#kegiatan").val();
        if (teks === "") return; 

        $("#daftar").append("<li>" + teks + " <button class='hapus'>Hapus</button></li>");
        $("#kegiatan").val(""); 
      });

      $("#daftar").on("click", ".hapus", function() {
        $(this).parent().fadeOut(300, function() {
          $(this).remove();
        });
      });
    });